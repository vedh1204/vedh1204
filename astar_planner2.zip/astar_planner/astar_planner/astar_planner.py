import rclpy
from rclpy.node import Node
from rclpy.time import Duration
from nav_msgs.msg import OccupancyGrid, Path
from geometry_msgs.msg import PoseStamped, PoseWithCovarianceStamped, Twist
from std_msgs.msg import Header
import numpy as np
import heapq
import tf_transformations
import math
from .map_loader import MapLoader

class AStarPlanner(Node):
    def __init__(self):
        super().__init__('a_star_planner')

        # Subscriptions
        self.map_sub = self.create_subscription(
            OccupancyGrid, '/map', self.map_callback, 10)
        self.goal_sub = self.create_subscription(
            PoseStamped, '/goal_pose', self.goal_callback, 10)
        self.start_sub = self.create_subscription(
            PoseWithCovarianceStamped, '/initialpose', self.start_callback, 10)

        # Publishers
        self.path_pub = self.create_publisher(Path, '/planned_path', 10)
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)

        # Initialize MapLoader
        self.map_loader = MapLoader(self)

        # Member variables
        self.map_data = None
        self.resolution = 0.0
        self.origin = None
        self.start = None
        self.goal = None

    def set_grid(self, grid_data):
        self.map_data = grid_data
        self.get_logger().info("Received grid data")

    def map_callback(self, msg):
        self.get_logger().info('Map received')
        self.map_data = np.array(msg.data, dtype=np.int8).reshape(
            (msg.info.height, msg.info.width))
        self.resolution = msg.info.resolution
        self.origin = msg.info.origin

    def start_callback(self, msg):
        self.get_logger().info('Start position received')
        self.start = msg.pose.pose.position

    def goal_callback(self, msg):
        self.get_logger().info('Goal received')
        self.goal = msg.pose.position
        if self.map_data is not None and self.start is not None:
            self.plan_path()

    def world_to_map(self, x, y):
        if self.origin is None or self.resolution == 0:
            self.get_logger().error("Map parameters not initialized!")
            return (0, 0)
        mx = int((x - self.origin.position.x) / self.resolution)
        my = int((y - self.origin.position.y) / self.resolution)
        return (mx, my)

    def map_to_world(self, mx, my):
        if self.origin is None or self.resolution == 0:
            self.get_logger().error("Map parameters not initialized!")
            return (0.0, 0.0)
        x = mx * self.resolution + self.origin.position.x + self.resolution / 2
        y = my * self.resolution + self.origin.position.y + self.resolution / 2
        return (x, y)

    def heuristic(self, a, b):
        return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2)

    def get_neighbors(self, node):
        neighbors = [(0, 1), (1, 0), (0, -1), (-1, 0)]
        result = []
        for dx, dy in neighbors:
            nx, ny = node[0] + dx, node[1] + dy
            if 0 <= nx < self.map_data.shape[1] and 0 <= ny < self.map_data.shape[0]:
                if self.map_data[ny][nx] == 0:
                    result.append((nx, ny))
        return result

    def plan_path(self):
        start_m = self.world_to_map(self.start.x, self.start.y)
        goal_m = self.world_to_map(self.goal.x, self.goal.y)

        if not self.is_valid(start_m) or not self.is_valid(goal_m):
            self.get_logger().error("Invalid start/goal position!")
            return

        open_set = []
        heapq.heappush(open_set, (0, start_m))
        came_from = {}
        g_score = {start_m: 0}

        while open_set:
            current = heapq.heappop(open_set)[1]

            if current == goal_m:
                path = []
                while current in came_from:
                    path.append(current)
                    current = came_from[current]
                path.reverse()
                self.publish_path(path)
                self.follow_path(path)
                return

            for neighbor in self.get_neighbors(current):
                tentative_g_score = g_score[current] + 1
                if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g_score
                    f_score = tentative_g_score + self.heuristic(neighbor, goal_m)
                    heapq.heappush(open_set, (f_score, neighbor))

        self.get_logger().warn("No path found!")

    def is_valid(self, grid_pos):
        x, y = grid_pos
        return (0 <= x < self.map_data.shape[1] and
                0 <= y < self.map_data.shape[0] and
                self.map_data[y][x] == 0)

    def publish_path(self, path):
        ros_path = Path()
        ros_path.header = Header()
        ros_path.header.frame_id = 'map'
        ros_path.header.stamp = self.get_clock().now().to_msg()

        for mx, my in path:
            pose = PoseStamped()
            pose.header.frame_id = 'map'
            pose.header.stamp = ros_path.header.stamp
            wx, wy = self.map_to_world(mx, my)
            pose.pose.position.x = wx
            pose.pose.position.y = wy
            pose.pose.orientation.w = 1.0
            ros_path.poses.append(pose)

        self.path_pub.publish(ros_path)
        self.get_logger().info(f"Published path with {len(ros_path.poses)} poses")

    def follow_path(self, path):
        for mx, my in path:
            target_x, target_y = self.map_to_world(mx, my)
            twist = Twist()
            twist.linear.x = 0.1
            self.cmd_vel_pub.publish(twist)
            self.get_clock().sleep_for(Duration(seconds=0.5))

        twist = Twist()
        self.cmd_vel_pub.publish(twist)
        self.get_logger().info("Path following completed")

def main(args=None):
    rclpy.init(args=args)
    planner = AStarPlanner()
    try:
        rclpy.spin(planner)
    except KeyboardInterrupt:
        pass
    finally:
        planner.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()



